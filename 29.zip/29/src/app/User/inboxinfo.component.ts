import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-inboxinfo',
  templateUrl: './inboxinfo.component.html',
  styles: []
})
export class InboxinfoComponent implements OnInit {
  Rid = localStorage.getItem("userToken");
  private maildetails: any = {};

  constructor(private service: ApihandlerService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      console.log(params.get('id'))
      var mailDes = { "mailId": params.get('id'), "rid": this.Rid };
      this.service.getmailDetails(mailDes).subscribe(k => {
        this.maildetails = k;
      })
    });
  }

}

import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-important',
  templateUrl: './user-important.component.html',
  styles: []
})
export class UserImportantComponent implements OnInit {
  private allmails: any = [];
  SelectedIDs: any = [];
  allmailtotrash: boolean = false;
  Rid = localStorage.getItem("userToken");

  constructor(private service: ApihandlerService, private toastr: ToastrService) { }
  getShortName(fullName) {
    return fullName.split(' ').map(n => n[0]).join('');
  }
  ngOnInit() {
    this.service.allMailFromImportant(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }
  DeleteTrash(mailId) {
    this.service.deleteFromTrash(mailId).subscribe(k => {
      if (k == "Success") {
        this.toastr.success('Deleted From Trash!', 'Success');
        this.ngOnInit();
      }
      else {
        this.toastr.error('Failed to Moved To Trash!', 'Error');
      }
    });
  }
}

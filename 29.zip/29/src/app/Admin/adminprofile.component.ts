import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrls: ['./adminprofile.component.css']
})
export class AdminprofileComponent implements OnInit {
  divprofile = true;
  divpass = true;
  constructor() { }

  ngOnInit() {
  }
  profile() {
    this.divprofile = false;
    this.divpass = true;
  }
  password() {
    this.divprofile = true;
    this.divpass = false;
  }
  close() {
    this.divprofile = true;
    this.divpass = true;
  }
}

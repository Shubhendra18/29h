import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminresetpass',
  templateUrl: './adminresetpass.component.html',
  styles: []
})
export class AdminresetpassComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

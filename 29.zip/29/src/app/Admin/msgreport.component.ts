import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-msgreport',
  templateUrl: './msgreport.component.html',
  styles: []
})
export class MsgreportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-lastloginreport',
  templateUrl: './lastloginreport.component.html',
  styles: []
})
export class LastloginreportComponent implements OnInit {
  loginrptData: any = [];
  dtOptions: DataTables.Settings = {
    
  };
  dtTrigger = new Subject();
  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.GetLastLogin().subscribe(k => {
      this.loginrptData = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers'
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}

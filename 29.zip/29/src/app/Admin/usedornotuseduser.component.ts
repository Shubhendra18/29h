import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
@Component({
  selector: 'app-usedornotuseduser',
  templateUrl: './usedornotuseduser.component.html',
  styles: []
})
export class UsedornotuseduserComponent implements OnInit {
  usedUserData: any = [];
  notusedUserData: any = [];
  @ViewChildren(DataTableDirective)
  dtElements: QueryList<any>;
  dtOptions: any = [];
  dtTrigger = new Subject();
  constructor(private service: ApihandlerService) { }
  displayToConsole(): void {
    this.dtElements.forEach((dtElement: DataTableDirective, index: number) => {
      dtElement.dtInstance.then((dtInstance: any) => {
        console.log(`The DataTable ${index} instance ID is: ${dtInstance.table().node().id}`);
      });
    });
  }
  ngOnInit() {
    this.service.GetUsedUser().subscribe(k => {
      this.usedUserData = k;
      this.dtTrigger.next();
    });
    this.service.GetNotUsedUser().subscribe(k => {
      this.notusedUserData = k;
    });

    this.dtOptions[0] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'Bfrtip', buttons: [
        'columnsToggle',
        'colvis',
        'copy',
        'print',
        'excel',
      ]
    };
    this.dtOptions[1] = {
      pageLength: 10, pagingType: 'full_numbers', dom: 'Bfrtip', buttons: [
        'columnsToggle',
        'colvis',
        'copy',
        'print',
        'excel',
      ]
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}

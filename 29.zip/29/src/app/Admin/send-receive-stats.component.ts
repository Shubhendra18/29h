import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-send-receive-stats',
  templateUrl: './send-receive-stats.component.html',
  styles: []
})
export class SendReceiveStatsComponent implements OnInit {
  sendrecstats: any = [];
  dtOptions: DataTables.Settings = {};
  dtTrigger = new Subject();
  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.GetsendreceiveStats().subscribe(k => {
      this.sendrecstats = k;
      this.dtTrigger.next();
    });
    this.dtOptions = {
      pageLength: 10, pagingType: 'full_numbers'
    };
  }
  trackByName(index: number, k: any): string {
    return k.groupName
  }
  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
}

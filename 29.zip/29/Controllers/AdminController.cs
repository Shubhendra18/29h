﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using MandiParishadWebApi.Filters;
using MandiParishadWebApi.Models;
using MandiParishadWebApi.Repository;

namespace MandiParishadWebApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("Admin")]
    public class AdminController : ApiController
    {
        AdminContext da = new AdminContext();
        Common objCom = new Common();
        DisplayMessage displayMessage = new DisplayMessage();
        [Route("UserLogin")]
        public IHttpActionResult PostUserLogin(UserLogin mail)
        {
            AfterUserLogin data = da.UserLogin(mail.officeName);
            if (data != null)
            {
                if (data.recflag.ToString() == "A")
                {
                    string dbpas = objCom.SingleHashing(mail.Password);
                    if (dbpas == data.password)
                    {
                        displayMessage.Message = "Login successfull";
                        displayMessage.Type = "s";
                        return Ok(new { displayMessage, data.officeName, data.userId });
                    }
                    else
                    {
                        HttpError myCustomError = new HttpError("Please Enter Valid Password") { { "Type", "w" } };
                        return Content(HttpStatusCode.BadRequest, myCustomError);
                    }
                }
                else
                {
                    HttpError myCustomError = new HttpError("Login Deactivated") { { "Type", "w" } };
                    return Content(HttpStatusCode.BadRequest, myCustomError);

                }
            }
            else
            {
                HttpError myCustomError = new HttpError("Please Enter Valid UserName") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);

            }
        }
        [Route("GroupMaster")]
        public IHttpActionResult GetGroup()
        {
            var data = da.M_GroupMaster.Where(k => k.isDeleted == false).ToList();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("AddUpdateGroupMaster")]
        public IHttpActionResult PostGroup(AddUpdateUserMaster groupMasterData)
        {
            var data = da.AddUpdateGroupName(groupMasterData.transId, groupMasterData.groupName, groupMasterData.userId);
            if (data.ToString() == "0")
            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Inserted") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("DeleteGroupMaster/{id}")]
        public IHttpActionResult DeleteGroup([FromUri]int id)
        {
            var data = da.DeleteGroup(id);
            if (data.ToString() == "0")
            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Deleted") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("AddUser")]
        public IHttpActionResult PostNewUser(AddUser userData)
        {
            var DisplayPassword = CGeneral.GetRendomPassword(8);
            userData.password = objCom.SingleHashing(DisplayPassword);
            String Msg = Convert.ToString(ConfigurationManager.AppSettings["UserCredentialsMsg"]).Replace("[ID]", userData.officeName).Replace("[Pass]", DisplayPassword);
            var data = da.AddUser(userData);
            if (data.ToString() == "0")
            {
                SMSSender.SMSSend(Msg, userData.mobileNo);
                return Ok("User has been registred successfully!");
            }
            else
            {
                HttpError myCustomError = new HttpError("Not Inserted") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("CheckUserName/{UserName}")]
        public IHttpActionResult GetCheckUserName([FromUri] string UserName)
        {
            var data = da.CheckUserName(UserName);
            if (data.ToString() == "0")

            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("This user name already exist. Please try with another username!") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetUsersCount")]
        public IHttpActionResult PostGetUsersCount(int groupId)
        {
            var data = da.GetUsersCount(groupId);
            if (data.ToString() == "0")

            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("You have completed maximum limit of user creation!") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetUserBygroup/{groupId}")]
        public IHttpActionResult GetUserBygroup(int groupId)
        {
            var data = da.GetGroupUsers(groupId);
            if (data != null)

            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No User Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("ComposeMail")]
        public IHttpActionResult PostComposeMail(MailBox mailBox)
        {
            string data = "";

            foreach (var k in mailBox.Rid)
            {
                data = da.ComposeMail(mailBox.Priority, mailBox.SMS, mailBox.Subject, mailBox.Message, mailBox.Sid, k.userId);
            }
            if (data == "success")
            {
                return Ok("Mail Send");
            }
            else
            {
                HttpError myCustomError = new HttpError("Unsuccessfull") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
            //Object data = 0;
            //Int64 Mailid = da.ComposeMail(mailBox);
            //if (Mailid > 0)
            //{
            //    foreach (var k in mailBox.Rid)
            //    {
            //        data = da.ComposeMailInfo(Mailid, k.userId, mailBox.Sid);
            //    }
            //    if (Convert.ToInt32(data) > 0)
            //    {
            //        data = "Mail Send";
            //    }
            //    return Ok(data);
            //}
            //else
            //{
            //    HttpError myCustomError = new HttpError("Unsuccessfull") { { "Type", "w" } };
            //    return Content(HttpStatusCode.BadRequest, myCustomError);
            //}
        }
        [Route("GetGroupUserForManage/{groupId}")]
        public IHttpActionResult GetGroupUserForManage(int groupId)
        {
            var data = da.GetGroupUsersforManage(groupId);
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("updateUserMaster")]
        public IHttpActionResult PutupdateUserMaster(UpdateuserModel model)
        {
            string msg = da.updateUserMaster(model);
            if (msg == "Success")
            {
                return Ok(msg);
            }
            else
            {
                HttpError myCustomError = new HttpError("Failed to Update No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("GetLastLogin")]
        public IHttpActionResult GetLastLogin()
        {
            List<LastLoginModel> data = da.GetlastloginReport();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("CheckGroupName/{groupName}")]
        public IHttpActionResult GetChecgroupName([FromUri] string groupName)
        {
            var data = da.CheckGroupName(groupName);
            if (data.ToString() == "0")

            {
                return Ok("Success");
            }
            else
            {
                HttpError myCustomError = new HttpError("This Group name already exist. Please try with another groupname!") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("SendReceiveStats")]
        public IHttpActionResult GetSendReceiveStats()
        {
            List<SendAndReceiveModel> data = da.GetSendAndReceiveMsgs();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("UsedUser")]
        public IHttpActionResult GetuseduserList()
        {
            List<UsedUser> data = da.GetUsedUser();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
        [Route("NotUsedUser")]
        public IHttpActionResult GetNotuseduserList()
        {
            List<UsedUser> data = da.GetNotUsedUser();
            if (data != null)
            {
                return Ok(data);
            }
            else
            {
                HttpError myCustomError = new HttpError("No Record Found") { { "Type", "w" } };
                return Content(HttpStatusCode.BadRequest, myCustomError);
            }
        }
    }
}

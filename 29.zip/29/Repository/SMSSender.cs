﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
namespace MandiParishadWebApi.Repository
{
    public class SMSSender
    {
        public static String SMSSend(String Message, String Mobile)
        {
            string s = string.Empty, r = string.Empty;
            try
            {
                WebClient Client = new WebClient();
                string baseurl = "http://sms6.routesms.com:8080/bulksms/bulksms?username=omninettr&password=1wHOuxrL&type=0&dlr=1&destination=" + Mobile + "&source=DCAIMS" + "&message=" + Message;
                Stream data = Client.OpenRead(baseurl);
                StreamReader reader = new StreamReader(data);
                s = reader.ReadToEnd();
                r = s.Substring(0, 4);
                if (r == "1701")
                {
                    r = "SUCCESS";
                }
                else
                {
                    r = "FAIL";
                }

                data.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                r += " " + ex.Message;
            }
            return r;
        }
    }
}